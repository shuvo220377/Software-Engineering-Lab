
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="css/uikit.min.css">
  <link rel="stylesheet" href="css/font-awesome.min.css">
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="style.css">
  <title>Probashi Food</title>
</head>
<body>
<nav class="navbar navbar-dark navbar-expand-md">
  <div class="container">
    <a href="index.php" class="navbar-brand">Probashi Food</a>
	<button class="navbar-toggler navbar-toggler-right" data-toggle="collapse" data-target="#navbarNav">
	  <span class="navbar-toggler-icon"></span>
	</button>
	<div id="navbarNav" class="collapse navbar-collapse">
	  <ul class="navbar-nav ml-auto">
	    <li class="nav-item">
		  <a href="index.php" class="nav-link">Home</a>
		</li>
		<li class="nav-item">
		  <a href="item.php" class="nav-link active">Items</a>
		</li>
		<li class="nav-item">
		  <a href="about.php" class="nav-link">About</a>
		</li>
		<li class="nav-item">
		  <a href="contact.php" class="nav-link">Contact</a>
		</li>
	  </ul>
	</div>
  </div>
</nav>
<!-- navigation end -->



<!-- food item start -->
<section id="food" class="text-dark py-5 text-center">
  <div class="container">
  <div class="text-center pb-5"><h2>Our Top Products</h2></div>
    <div class="row">
	  <div class="col-md-4">
	    <div class="card">
		  <div class="card-body">
		    <img class="kkk" src="img/image1.jpg"/>
			<p class="lead pt-3">click the button for details</p>
			<a class="btn btn-primary text-light">Learn More</a>
		  </div>
		</div>
	  </div>
	  <div class="col-md-4">
	    <div class="card">
		  <div class="card-body">
		    <img class="kkk"src="img/image2.jpg"/>
			<p class="lead pt-3">click the button for details</p>
			<a class="btn btn-primary text-light">Learn More</a>
		  </div>
		</div>
	  </div>
	  <div class="col-md-4">
	    <div class="card">
		  <div class="card-body">
		    <img class="kkk" src="img/image3.jpg"/>
			<p class="lead pt-3">click the button for details</p>
			<a class="btn btn-primary text-light">Learn More</a>
		  </div>
		</div>
	  </div>
	</div>
  </div>
</section>
<!-- food item end -->







<!-- footer start -->
<section id="footer" class="text-center py-3 text-light">
  <div class="container">
    <div class="row">
	  <div class="col">
	    <p class="lead mb-0">copyright &copy;Shuvo,Fahim,Jamill</p>
	  </div>
	</div>
  </div>
</section>
<!-- footer end -->



  <script src="js/jquery.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/uikit.min.js"></script>
  <script src="js/uikit-icons.min.js"></script>
  <script src="js/main.js"></script>
</body>
</html>