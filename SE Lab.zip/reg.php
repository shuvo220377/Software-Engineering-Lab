<?php
   include 'config.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="css/uikit.min.css">
  <link rel="stylesheet" href="css/font-awesome.min.css">
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="style.css">
  <title>Probashi Food/Registration Form</title>
</head>






  
  
  <div class="row py-5">

 <div class="col-sm-4"></div>
 
 
 
 
 <div class="col-sm-4 text-center">
	   <div class="card">
	     <div class="card-body">
		   <h4 class="text-center">Please Fill The Reistration Form</h4>
		   <hr>
		   
	
		    <form method="POST" action="reg.php">
		 
		   
			   <input type="text" placeholder="User Name" class="form-control my-2" name="name" required>
			
			   <input type="email" placeholder="Email" class="form-control mb-2" name="email" required>
			
			   <input type="passward" placeholder="Passward" class="form-control mb-2" name="pass" required>
		
			   <input type="passward" placeholder="Confirm Passward" class="form-control mb-3" name="cpass" required>
			
			<input name="reg" type="submit" id="button" value="Sign-up"/>
			<a href="login.php"><input name="back" type="button" id="button" value="Login"/></a>
				
				
		 
		    </form>
			
			
			
			
<?php


if(isset($_POST['reg'])){
	
	$name 	= $_POST['name'];
	$email  = $_POST['email'];
	$pass   = $_POST['pass'];
	$cpass  = $_POST['cpass'];
	
	if($pass == $cpass){
		
		$query = "select*from user where email='$email'";
		
		$query_check = mysqli_query($con,$query);
		
		
		if($query_check){
			
			if(mysqli_num_rows($query_check)>0){
				
				echo "
					<script>
					   alert('Email already in use');
					   window.location.href='login.php';
					</script>
				
				";
				
			}else{
				$insertion = "insert into user values('$name','$email','$pass')";
				
				$run = mysqli_query($con,$insertion);
				
				if($run){
					
					echo "
					<script>
					   alert('You are successfully registerd');
					   window.location.href='index.php';
					</script>
				
				";
				}
				else{
					echo "
					<script>
					   alert('Connection failed');
					   window.location.href='reg.php';
					</script>
				
				";
				}
				
			}
			
		}else{
			echo "
					<script>
					   alert('Database Error');
					   window.location.href='reg.php';
					</script>
				
				";
		}
		
		
		
	}else{
		echo "
					<script>
					   alert('Passward and Confirm Passward doesn't match');
					   window.location.href='reg.php';
					</script>
				
				";
	}
	
}
else{
	
}







?>
			
			
			
			
			<div class="col-sm-4"></div>
			
		 </div>
	   </div>
</div>








</div>

<!-- footer start -->
<section id="footer" class="text-center py-3 text-light">
  <div class="container">
    <div class="row">
	  <div class="col">
	    <p class="lead mb-0">copyright &copy;Shuvo,Fahim,Jamil</p>
	  </div>
	</div>
  </div>
</section>
<!-- footer end -->



  <script src="js/jquery.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/uikit.min.js"></script>
  <script src="js/uikit-icons.min.js"></script>
  <script src="js/main.js"></script>
</body>
<!-- body end -->
</html>