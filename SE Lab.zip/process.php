<?php

	if(isset($_POST['submit'])){
		$fname = $_POST['firstname'];
		$lname = $_POST['lastname'];
		$email = $_POST['email'];
		$phone = $_POST['phone'];
		$message = $_POST['message'];
		
		if(empty($fname) || empty($lname) || empty($email) || empty($phone) || empty($message)){
			header('location:contact.php?error');
		}
		else{
			$to = "shovo420520@gmail.com";
			if(mail($to,$email,$message)){
				header("location:contact.php?success");
			}
		}
		
	}
	else{
		header("location:contact.php");
	}
	

?>