<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="css/uikit.min.css">
  <link rel="stylesheet" href="css/font-awesome.min.css">
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="style.css">
  <title>Probashi Food</title>
</head>
<body>
<nav class="navbar navbar-dark navbar-expand-md">
  <div class="container">
    <a href="index.php" class="navbar-brand">Probashi Food</a>
	<button class="navbar-toggler navbar-toggler-right" data-toggle="collapse" data-target="#navbarNav">
	  <span class="navbar-toggler-icon"></span>
	</button>
	<div id="navbarNav" class="collapse navbar-collapse">
	  <ul class="navbar-nav ml-auto">
	    <li class="nav-item">
		  <a href="index.php" class="nav-link">Home</a>
		</li>
		<li class="nav-item">
		  <a href="item.php" class="nav-link">Items</a>
		</li>
		<li class="nav-item">
		  <a href="about.php" class="nav-link active">About</a>
		</li>
		<li class="nav-item">
		  <a href="contact.php" class="nav-link">Contact</a>
		</li>
	  </ul>
	</div>
  </div>
</nav>
<!-- navigation end -->


<section id="about" class="bg-dark py-5 text-light">
<div class="container">
  <div class="row">
    <div class="col-md-6">
	  <img src="img/about.jpg"/>
	</div>
	<div class="col-md-6">
	  <h2>About Probashi Food</h2>
	  <p class="lead">Stepping into 20th Century, starting venture since 2000. The Probashi Food is proclaiming luster presence in business arena and made a remarkable history in the private sector era that has been nourished and bloomed in different business concerns. Where most of the projects are telling successful stories resulting in playing a vital role to our economy. </p>
	</div>
  </div>
 </div>
</section>








<!-- footer start -->
<section id="footer" class="text-center py-3 text-light">
  <div class="container">
    <div class="row">
	  <div class="col">
	    <p class="lead mb-0">copyright &copy;Shuvo,Fahim,Jamil</p>
	  </div>
	</div>
  </div>
</section>
<!-- footer end -->



  <script src="js/jquery.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/uikit.min.js"></script>
  <script src="js/uikit-icons.min.js"></script>
  <script src="js/main.js"></script>
</body>
</html>