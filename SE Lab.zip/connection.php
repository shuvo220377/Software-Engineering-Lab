<?php


$conn = mysqli_connect("localhost","root","","registrationdb");
if(!$conn){
	echo "database connection faild";
}

	$fname = $_POST['firstname'];
	$lname = $_POST['lastname'];
	$gender = $_POST['gender'];
	$email = $_POST['email'];
	$passward = $_POST['passward'];
	
	$sql = "INSERT INTO login(Firstname,Lasatname,Gender,Email,Passward) VALUES ($fname,$lname,$gender,$email,$passward)";
	$result = mysqli_query($conn,$sql);
		if($result){
			header("location:login.php");
		}
		else{
			echo "Error".$sql;
		}
		
		
		
		
?>