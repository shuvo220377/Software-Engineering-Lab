<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="css/uikit.min.css">
  <link rel="stylesheet" href="css/font-awesome.min.css">
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="style.css">
  <title>Probashi Food</title>
</head>

<!-- body start -->
<body>

<!-- header-section start -->
<nav class="navbar navbar-dark navbar-expand-md">
  <div class="container">
    <a href="index.php" class="navbar-brand">Probashi Food</a>
	<button class="navbar-toggler navbar-toggler-right" data-toggle="collapse" data-target="#navbarNav">
	  <span class="navbar-toggler-icon"></span>
	</button>
	<div id="navbarNav" class="collapse navbar-collapse">
	  <ul class="navbar-nav ml-auto">
	    <li class="nav-item">
		  <a href="index.php" class="nav-link">Home</a>
		</li>
		<li class="nav-item">
		  <a href="index.php" class="nav-link">Items</a>
		</li>
		<li class="nav-item">
		  <a href="about.php" class="nav-link">About</a>
		</li>
		<li class="nav-item">
		  <a href="contact.php" class="nav-link active">Contact</a>
		</li>
	  </ul>
	</div>
  </div>
</nav>
<!-- header-section end -->




<section id="#contact" class="py-5" method="POST" action="">
  <div class="container">
    <div class="row">
	 <div class="col-md-8">
	   <div class="card">
	     <div class="card-body">
		   <h4 class="text-center">Please fill out this form to contact us</h4>
		   <hr>
		   
		   <?php
		      $warning = "";
			  if(isset($_GET['error'])){
				  $warning = "please fill in the blanks!";
				  echo '<div class="alert alert-danger">'.$warning.'</div>';
			  }
			  if(isset($_GET['success'])){
				   $warning = "your message have been sent!";
				  echo '<div class="alert alert-success">'.$warning.'</div>';
			  }
			  
		   ?>
		    <form method="post" action="process.php">
		   <div class="row mt-4">
		  
		   <div class="col-md-6">
		     <div class="form-group">
			   <input type="text" placeholder="First Name" class="form-control" name="firstname">
			 </div>
		   </div>
		   
		   <div class="col-md-6">
		     <div class="form-group">
			   <input type="text" placeholder="Last Name" class="form-control" name="lastname">
			 </div>
		   </div>
		   
		   <div class="col-md-6">
		     <div class="form-group">
			   <input type="email" placeholder="Email" class="form-control" name="email">
			 </div>
		   </div>
		   
		   <div class="col-md-6">
		     <div class="form-group">
			   <input type="text" placeholder="Phone Number" class="form-control" name="phone">
			 </div>
		   </div>
		   
		   <div class="col-md-12">
		     <div class="form-group">
			   <textarea cols="30" rows="5" class="form-control" placeholder="Message" name="message"></textarea>
			 </div>
		   </div>
		   
		   <div class="col-md-12">
		     <input type="submit" class="btn btn-block btn-primary" value="send" name="submit">
		   </div>
		  
		   </div>
		    </form>
		 </div>
	   </div>
	 </div>
	 
	 
	 
	 <div class="col-md-4">
	   <div class="card">
	     <div class="card-body">
		   <h4>Address</h4>
		   <p>House #50, Motijil, Dhaka, Bangladesh</p>
		   <h4>Email</h4>
		   <p>email@gmail.com</p>
		   <h4>Phone</h4>
		   <p class="mb-1">123-456-789</p>
		   <p>987-654-321</p>
		 </div>
	   </div>
	 </div>
	 
	</div>
  </div>
</section>






<!-- footer start -->
<section id="footer" class="text-center py-3 text-light">
  <div class="container">
    <div class="row">
	  <div class="col">
	    <p class="lead mb-0">copyright &copy;Shuvo,Fahim,Jamil</p>
	  </div>
	</div>
  </div>
</section>
<!-- footer end -->



  <script src="js/jquery.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/uikit.min.js"></script>
  <script src="js/uikit-icons.min.js"></script>
  <script src="js/main.js"></script>
</body>
<!-- body end -->
</html>