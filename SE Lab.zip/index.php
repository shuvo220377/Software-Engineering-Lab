<?php

include  'config.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="css/uikit.min.css">
  <link rel="stylesheet" href="css/font-awesome.min.css">
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="style.css">
  <title>Probashi Food</title>
</head>
<body>

<!-- Navigation ber start -->
<nav class="navbar navbar-dark navbar-expand-md" method="POST" action="index.php">
  <div class="container">
    <a href="index.php" class="navbar-brand">Probashi Food</a>
	<button class="navbar-toggler navbar-toggler-right" data-toggle="collapse" data-target="#navbarNav">
	  <span class="navbar-toggler-icon"></span>
	</button>
	<div id="navbarNav" class="collapse navbar-collapse">
	  <ul class="navbar-nav ml-auto">
	    <li class="nav-item">
		  <a href="index.php" class="nav-link active">Home</a>
		</li>
		<li class="nav-item">
		  <a href="item.php" class="nav-link">Items</a>
		</li>
		<li class="nav-item">
		  <a href="about.php" class="nav-link">about</a>
		</li>
		<li class="nav-item">
		  <a href="Contact.php" class="nav-link">Contact</a>
		</li>
		<li class="nav-item">
		  <a name="logout" href="login.php" class="nav-link btn btn-primary">logout</a>
		</li>
		<!--<input name="logout" type="button" id="button" value="Logout"/>-->
	  </ul>
	</div>
  </div>
</nav>
<!-- Navigation ber end -->


<?php

	if(isset($_POST['logout'])){
		echo"
					<script>
						alert('You are successfully logged out');
						window.location.href='login.php';
					</script>
				";
	}else{
		//logout
	}

?>


<!-- slider-option start -->
<section id="showcase" class="bg-dark">
  <div id="slide"class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-slide-to="0" data-target="#slide" class="active"></li>
    <li data-slide-to="1" data-target="#slide"></li>
    <li data-slide-to="2" data-target="#slide"></li>
  </ol>
    <div class="carousel-inner">
	  <div class="carousel-item carousel-img-1 active">
	    <div class="container">
		  <div class="carousel-caption text-light text-center mb-5 pb-5">
		    <h2 class="display-4">Slide One</h2>
			<p class="lead">To know more about our product click the button...</p>
			<a class="btn btn-primary">Learn More</a>
		  </div>
		</div>
	  </div>
	  
	  <div class="carousel-item carousel-img-2">
	    <div class="container">
		  <div class="carousel-caption text-light text-center mb-5 pb-5">
		    <h2 class="display-4">Slide Two</h2>
			<p class="lead">To know more about our product click the button...</p>
			<a class="btn btn-warning">Learn More</a>
		  </div>
		</div>
	  </div>
	  
	  <div class="carousel-item carousel-img-3">
	    <div class="container">
		  <div class="carousel-caption text-dark text-center mb-5 pb-5">
		    <h2 class="display-4">Slide Three</h2>
			<p class="lead">To know more about our product click the button...</p>
			<a class="btn btn-success">Learn More</a>
		  </div>
		</div>
	  </div>
	</div>
	<a href="#slide" class="carousel-control-prev" data-slide="prev">
	  <span class="carousel-control-prev-icon"></span>
	</a>
	<a href="#slide" class="carousel-control-next" data-slide="next">
	  <span class="carousel-control-next-icon"></span>
	</a>
  </div>
</section>
<!-- slider-option end -->



<!-- operade option start -->
<section id="operade" class="py-5 bg-dark text-light">
  <div class="container">
    <div class="row">
	  <div class="col-md-6">
	    <img src="img/operade.jpg"/>
	  </div>
	  <div class="col-md-6 pt-3 text-right">
	    <h1>How do we operade</h1>
		<p class="lead">Baked goods have been around for thousands of years. The art of baking was developed early during the Roman Empire. It was a highly famous art as Roman citizens loved baked goods and demanded for them frequently for important occasions such as feasts and weddings etc. Due to the fame and desire that the art of baking received, around 300 BC, baking was introduced as an occupation and respectable profession for Romans. The bakers began to prepare bread at home in an oven, using mills to grind grain into the flour for their breads. The oncoming demand for baked goods vigorously continued and the first bakers' guild was established in 168 BC in Rome. This drastic appeal for baked goods promoted baking all throughout Europe and expanded into the eastern parts of Asia. Bakers started baking breads and goods at home and selling them out on the streets.</p>
	  </div>
	</div>
  </div>
</section>
<!-- operade option end -->


<!-- sell option start -->
<section id="sell" class="py-5 text-light">
  <div class="container">
    <div class="row">
	  <div class="col-md-6 mt-5 pt-5">
	    <h1>How much product we sell</h1>
		<p class="lead"> One of the offshoots of the rising popularity in cookies in America has been an explosion of online options for cookie lovers. Insomnia Cookies already has more than 158 locations nationwide in 40 states and the District of Columbia. Insomnia Cookies is a rapidly expanding late-night bakery. In 2019 alone, Insomnia Cookies has opened 12 locations, and plans to open more before the year ends, including locations like USA,Canada,England,Saudi Arabia,Oman,UAE etc.
			   </p>
	  </div>
	  <div class="col-md-6">
	    <img src="img/operade.jpg"/>
	  </div>
	</div>
  </div>
</section>
<!-- sell option end -->



<!-- payment part start -->
<section id="payment" class="text-center py-5">
  <div class="container">
    <div class="row">
	  <div class="col">
	    <a href="payment.html" class="btn btn-danger">Payment</a>
	    <a href="reg.php" class="btn btn-success">Registration</a>
	  </div>
	</div>
  </div>
</section>
<!-- payment part end -->




<!-- client part start -->
<section id="client" class="py-5 text-center text-light bg-dark">
  <div class="container">
  <div class="raw">
    <h1>Our Top Client</h1>
  </div>
    <div class="row pt-5">
	  <div class="col-md-4">
	    <img class="photo" src="img/client1.jpg"/>
		<h3 class="pt-2">Mark,UK</h3>
	  </div>
	  <div class="col-md-4">
	    <img class="photo" src="img/client2.jpg"/>
		<h3 class="pt-2">Stive,Canada</h3>
	  </div>
	  <div class="col-md-4">
	    <img class="photo" src="img/client3.jpg"/>
		<h3 class="pt-2">Philip,USA</h3>
	  </div>
	</div>
  </div>
</section>
<!-- client part end -->









<!-- footer start -->
<section id="footer" class="text-center py-3 text-light">
  <div class="container">
    <div class="row">
	  <div class="col">
	    <p class="lead mb-0">copyright &copy;Shuvo,Fahim,Jamil</p>
	  </div>
	</div>
  </div>
</section>
<!-- footer end -->





  


  <script src="js/jquery.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/uikit.min.js"></script>
  <script src="js/uikit-icons.min.js"></script>
  <script src="js/main.js"></script>
</body>
</html>
